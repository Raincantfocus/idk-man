extends SceneTree
func _initialize() -> void:
 for name: String in ["body_set_enable_continuous_collision_detection","body_get_direct_state"]:print(name," ",ClassDB.class_has_method("PhysicsServer3D",name))
 quit()
