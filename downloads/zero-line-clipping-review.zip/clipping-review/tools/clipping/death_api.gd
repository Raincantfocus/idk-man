extends SceneTree
func _initialize() -> void:
 var result: Dictionary={}
 for name: String in ["PhysicalBoneSimulator3D","PhysicalBone3D","PhysicsDirectSpaceState3D","SkeletonModifier3D","PhysicsShapeQueryParameters3D","PhysicsRayQueryParameters3D","CharacterBody3D","AnimationTree"]:
  result[name]={"methods":ClassDB.class_get_method_list(name,true),"properties":ClassDB.class_get_property_list(name,true)}
 var file:=FileAccess.open("/tmp/death-api.json",FileAccess.WRITE);file.store_string(JSON.stringify(result));file.close();quit()
