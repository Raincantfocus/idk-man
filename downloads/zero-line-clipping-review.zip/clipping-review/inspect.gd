extends SceneTree
func _initialize() -> void:
 for path: String in ["res://motions/run_loop.glb","res://models/body.glb"]:
  var scene: Node=(load(path) as PackedScene).instantiate();root.add_child(scene)
  scene.print_tree_pretty()
  for sk: Node in scene.find_children("*","Skeleton3D",true,false):print("RIG ",scene.get_path_to(sk)," ",(sk as Skeleton3D).get_bone_count())
  for p: Node in scene.find_children("*","AnimationPlayer",true,false):print("ANIMS ",(p as AnimationPlayer).get_animation_list())
  scene.free()
 quit()
