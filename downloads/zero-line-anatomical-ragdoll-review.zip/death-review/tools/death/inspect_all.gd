extends SceneTree
func _initialize() -> void:
 for file: String in DirAccess.get_files_at("res://death_motions"):
  if not file.ends_with(".glb"):continue
  var source: Node=(load("res://death_motions/"+file) as PackedScene).instantiate()
  for sk: Skeleton3D in source.find_children("*","Skeleton3D",true,false):print(file," ",sk.find_bone("Hips")," first ",sk.get_bone_name(1))
  source.free()
 quit()
