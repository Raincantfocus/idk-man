# Animation integration review

Open project.godot in Godot 4.6.3, allow import, press F5. Keep the GLB.import files: they contain required humanoid retarget settings.

Eight supplied mocap clips plus an explicitly static hold pose. Controls expose run blending, upper-body fire/reload, full clips, pause, Focus, rotation and gear visibility. See docs/ANIMATION_INTEGRATION_REVIEW.md for the failed acceptance items.

This is an isolated review, not the playable wave shooter. Clothing intersections, weapon/foot contact, missing role clips, over-budget geometry and ragdoll integration remain unresolved. Original supplied-asset license terms apply.
