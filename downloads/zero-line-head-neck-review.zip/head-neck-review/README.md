# Head/neck region review — NOT production approved

Open project.godot in Godot 4.6, let imports finish, then press F5. Use the buttons
for state, view, pose and torn variant. Open/detached offsets are exploded review
positions, not physics. Interiors stay unloaded in the interactive presentation.

This is an isolated art review, not the playable shooter. No gameplay changes.
Read validation.json, geometry_validation.json and godot_validation.json for
actual failures and unverified checks. Software-rendered frame times are invalid.

Regenerate from the packed fitted source (Blender 4.3+):

    blender -b --disable-autoexec --python-exit-code 1 source/head_standard.blend -P tools/characters/author_head_neck.py -- ../head-neck-generated

Validate the generated geometry:

    blender -b --disable-autoexec --python-exit-code 1 ../head-neck-generated/authoring/head_neck_authoring.blend -P tools/characters/audit_head_neck_region.py -- ../head-neck-generated

Source and authoring .blend files include packed textures. Texture dimensions,
weights and anatomical dimensions remain candidates, not medical measurements.
The only converted supplied head here is Soup, on the shared fitted rig. Other
bodies and regions await the user's region review gate.

LICENSE: supplied soldier art is user-purchased; redistribution terms have not
been verified. Keep this package private. The shared rig derives from MakeHuman
CC0 assets; see LICENSE.MAKEHUMAN-ASSETS.md. Scripts are project code.
