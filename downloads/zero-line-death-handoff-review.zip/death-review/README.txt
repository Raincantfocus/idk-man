UNAPPROVED death handoff review. Godot 4.6.3. Import project.godot and press F5.
Read docs/DEATH_HANDOFF_REVIEW.md for failures, controls and tests.
This is an isolated review, not the playable game.
