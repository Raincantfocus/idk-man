# Body / gear clipping review — NOT APPROVED

Open `project.godot` in Godot **4.6.3**, let import finish, and press F5. Keep every `.glb.import` file: these contain the humanoid retarget settings.

This isolated review has the local carrier attachment repair plus experimental A–E fitting adjustments. It is not a new playable game release. Remaining clipping, garment fit, missing clips/variants and excess triangles prevent approval. Gameplay code is unchanged.

- **R**: reveal all skin / hide covered skin.
- **M**: coverage colors. Use **Gear** to see the mask without clothing.
- **C**: toggle nearby corrective candidates.
- Existing buttons select authored clips, locomotion, pause, Focus and rotation.
- Open `baseline_review.tscn` for the untouched baseline.

Read `docs/BODY_GEAR_CLIPPING_REVIEW.md`. Raw per-clip/region CSVs, measurements and screenshots are in `audit/`. Blue mask vertices are retained; orange vertices are covered. Original asset licenses still apply.

To rerun the geometry pipeline with Blender 4.3.2 and bundled inputs:

```bash
bash tools/clipping/reproduce.sh /tmp/zero-line-clipping-rerun
```

This takes several minutes and intentionally reports failed acceptance. The baseline snapshot was exported from Godot, not synthesized. To re-export it, run `tools/clipping/export_measurement.gd` against this project and supply its output file argument. It selects `baseline_review.tscn`, never the patched scene.

LOD1–3 covered copies are supplied alongside unmasked originals. They are not connected to live character LOD/reveal selection. Do not use covered LODs for a revealed wound without swapping to the unmasked mesh and a fitted torn garment state. GPU timings are unverified: captures used llvmpipe software rendering.
