extends SceneTree
func _initialize() -> void:
 var source: Node=(load("res://models/body.glb") as PackedScene).instantiate();var rigs: Array[Node]=source.find_children("*","Skeleton3D",true,false)
 for sk: Skeleton3D in rigs:
  print("BONES ",sk.get_bone_count()," Hips ",sk.find_bone("Hips"))
  for i: int in mini(10,sk.get_bone_count()):print(sk.get_bone_name(i))
 for player: AnimationPlayer in source.find_children("*","AnimationPlayer",true,false):print("CLIPS ",player.get_animation_list())
 source.free();quit()
