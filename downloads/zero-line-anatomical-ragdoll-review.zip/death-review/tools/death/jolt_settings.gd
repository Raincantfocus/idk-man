extends SceneTree
func _initialize() -> void:
 for p: Dictionary in ProjectSettings.get_property_list():
  if "jolt" in String(p.name):print(p.name,"=",ProjectSettings.get_setting(p.name))
 quit()
