# Body-zone review

Open project.godot in Godot 4.6.3 and press F5.

45 rest-pose caps, 22 zone definitions and cavity logic. This is an isolated art review, not the playable shooter. See docs/BODY_ZONE_REVIEW.md for failed acceptance items.

The packed Blender file, CC0-derived source body, atlas, authoring scripts and provenance are included. No animation or full-body cloth joins are claimed.
