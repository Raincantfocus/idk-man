# Head/neck cap rework review

Open project.godot in Godot 4.6.3, wait for import, press F5. Controls cycle 12
variants, three distances, two light rigs and LODs. Pulse, Drop head and Head pop
exercise isolated cosmetic effects. Jolt is selected for the review project.

This review is not yet an approved live-game replacement. See docs/NECK_REWORK_REVIEW.md
for actual checks, measured counts and remaining visual/integration failures.
Compatibility uses a surface-mesh blood-pool fallback. Forward+ Decal rendering
and GPU frame cost were not validated on this software-rendered host.

Includes native captures, packed authoring .blend and runnable scripts. Purchased
source assets remain subject to their original terms. The user explicitly approved
public GitHub delivery of these review archives.

The authoring .blend contains all generated meshes and packed images. Rebuilding
from the original fitted region also requires the previous head/neck package's
source .blend plus its manifest.json; the generator usage is documented in the
review report. No external cloud-only texture paths are required to inspect/edit
this packed authoring file.
