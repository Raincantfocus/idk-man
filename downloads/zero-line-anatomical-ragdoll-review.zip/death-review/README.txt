Godot 4.6.3 death playback review. Import project.godot and press F5. Default clip playback includes collisions and ragdoll; Animation preview is an explicit bypass.
Read docs/RIGHT_DEATH_PLANT_FIX.md and docs/PLAYBACK_TRANSITION_FIX.md for fixes, measurements and remaining quality limits.
This is an isolated review, not the playable game.
